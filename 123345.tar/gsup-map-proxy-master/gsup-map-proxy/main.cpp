// main.cpp
#include <cstring>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <chrono>
#include <memory>

#include "tcap_encoder.h"
#include "map_encoder.h"
#include "gsup_to_map_proxy.h"

extern "C" {
#include "gsup_server.h"
#include <osmocom/core/application.h>
#include <osmocom/core/logging.h>
#include <osmocom/core/select.h>
#include <osmocom/core/talloc.h>
#include <osmocom/core/utils.h>
#include <osmocom/core/panic.h>
#include <osmocom/core/msgb.h>

#include <osmocom/gsm/gsup.h>
#include <osmocom/gsm/gsm48_ie.h>
#include <osmocom/gsm/gsm23003.h>
#include <osmocom/gsm/gsm48.h>

#include <osmocom/gsupclient/gsup_client.h>
#include <osmocom/gsupclient/gsup_client_mux.h>
#include <osmocom/gsupclient/gsup_req.h>

#include "hlr_1.h"
#include "stp_initilizer.h"
//#include "map_sai_parser.h"
//#include "tcap_parser.h"
//#include "map_isd_parser.h"
}

#include "proxy_core.h"
#include "transaction_table.h"

void *tall_stp_ctx = NULL;
struct hlr *gsup_to_map_proxy = NULL;

static std::unique_ptr<grproxy::ProxyCore> g_proxy_core;



// ============================================================================
// Callbacks: external I/O
// ============================================================================

static int send_gsup_via_osmo(void* conn, struct msgb* msg) {
    if (!conn || msg == NULL) {
        return -EINVAL;
    }
    return osmo_gsup_conn_send(static_cast<osmo_gsup_conn*>(conn), msg);
}

static int send_tcap_via_sccp(uint8_t* data, int len) {
    if (!data || len == 0) {
        return -EINVAL;
    }
    // Uses config from stp_initializer.c internally
    send_sccp_message_encoded(data, len);
    return 0;
}

void process_msg_from_hlr(uint8_t *tcap_data , unsigned int tcap_len ) {
    if (g_proxy_core) {
        g_proxy_core->on_recv_tcap_msg(tcap_data, tcap_len);
    }
}

static void my_gsup_connect_cb(bool connected)
{

    g_proxy_core->on_gsup_connection( connected);

}

// ============================================================================
// GSUP request handler
// ============================================================================

static int my_gsup_read_cb(struct osmo_gsup_conn* conn, struct msgb* msg) {
    struct osmo_gsup_req* req = osmo_gsup_conn_rx(conn, msg);
    if (!req) {
        return -EINVAL;
    }

    LOGP(DLGSUP, LOGL_INFO, "RX %s for IMSI: %s\n",
         osmo_gsup_message_type_name(req->gsup.message_type),
         req->gsup.imsi ?: "N/A");

    grproxy::TransactionContext ctx;
    if (req->gsup.imsi) {
        strncpy(ctx.imsi, req->gsup.imsi, sizeof(ctx.imsi) - 1);
        ctx.imsi[sizeof(ctx.imsi) - 1] = '\0';
    }
    ctx.cn_domain = req->gsup.cn_domain;

    if (g_proxy_core) {
        grproxy::ProxyCore::Result rc = g_proxy_core->on_gsup_request(
            static_cast<void*>(conn),
            &req->gsup,
            &ctx
            );

        if (rc == grproxy::ProxyCore::Result::SUCCESS) {
            osmo_gsup_req_free(req);
            return 0;
        }
        LOGP(DLGSUP, LOGL_ERROR, "Proxy processing failed: %d\n", static_cast<int>(rc));
    }

    enum osmo_gsup_message_type error_type;
    switch (req->gsup.message_type) {
    case OSMO_GSUP_MSGT_SEND_AUTH_INFO_REQUEST:
        error_type = OSMO_GSUP_MSGT_SEND_AUTH_INFO_ERROR;
        break;
    case OSMO_GSUP_MSGT_UPDATE_LOCATION_REQUEST:
        error_type = OSMO_GSUP_MSGT_UPDATE_LOCATION_ERROR;
        break;
    case OSMO_GSUP_MSGT_INSERT_DATA_REQUEST:
        error_type = OSMO_GSUP_MSGT_INSERT_DATA_ERROR;
        break;
    default:
        error_type = OSMO_GSUP_MSGT_ROUTING_ERROR;
        break;
    }

    osmo_gsup_req_respond_msgt(req, error_type, true);
    return 0;
}

// ============================================================================
// Timers
// ============================================================================

static void cleanup_timer_cb(void* data) {
    if (g_proxy_core) {
        g_proxy_core->periodic_cleanup(std::chrono::seconds(60));
    }
    struct osmo_timer_list* timer = static_cast<struct osmo_timer_list*>(data);
    if (timer) {
        osmo_timer_schedule(timer, 30, 0);
    }
}

// Helper for random TID (moved from old code)
static inline uint32_t generate_random_tid(void) {
    uint32_t tid = ((uint32_t)(rand() & 0xFF) << 24) |
                   ((uint32_t)(rand() & 0xFF) << 16) |
                   ((uint32_t)(rand() & 0xFF) << 8)  |
                   ((uint32_t)(rand() & 0xFF));
    return tid ? tid : 0xDEADBEEF;
}

static void send_timer_cb(void* data) {
    // Используем правильный геттер из stp_initializer.h
    const struct gsup_proxy_cfg *cfg = get_full_proxy_cfg();

    // Обращаемся к вложенной структуре test_sai
    if (!cfg || !cfg->test_sai.enabled) {
        // Reschedule anyway in case config changes later
        struct osmo_timer_list* timer = static_cast<struct osmo_timer_list*>(data);
        if (timer) osmo_timer_schedule(timer, 10, 0);
        return;
    }

    // Iterate over configured IMSIs
    struct imsi_entry *entry; // Используем тип из stp_initializer.h
    llist_for_each_entry(entry, &cfg->test_sai.imsi_list, list) {

        Component_t *component = NULL;
        uint8_t *tcap_pdu = NULL;
        size_t pdu_len = 0;

        // Create SAI Component
        if (create_map_sai_component(1, entry->imsi_str, &component) == 0) {
            if (generate_tcap_begin(generate_random_tid(), &component, 1, &tcap_pdu, &pdu_len, 56, proxy_cfg.add_tcap_dialog_portion) == 0) {
                send_sccp_message_encoded(tcap_pdu, pdu_len);
                free(tcap_pdu);
            }
            // ASN_STRUCT_FREE(asn_DEF_Component, component); // Раскомментируйте если нужно
        }

        // Create UpdateLocation Component (Optional)
        component = NULL;
        if (create_map_ul_gprs_component(1, entry->imsi_str, &component) == 0) {
            if (generate_tcap_begin(generate_random_tid(), &component, 1, &tcap_pdu, &pdu_len, 0x17, proxy_cfg.add_tcap_dialog_portion) == 0) {
                send_sccp_message_encoded(tcap_pdu, pdu_len);
                free(tcap_pdu);
            }
        }

        component = NULL;
        if (create_map_purge_ms_component(1, entry->imsi_str, &component) == 0) {
            if (generate_tcap_begin(generate_random_tid(), &component, 1, &tcap_pdu, &pdu_len, 0x43, proxy_cfg.add_tcap_dialog_portion) == 0) {
                send_sccp_message_encoded(tcap_pdu, pdu_len);
                free(tcap_pdu);
            }
        }
    }

    struct osmo_timer_list* timer = static_cast<struct osmo_timer_list*>(data);
    if (timer) {
        // Доступ к интервалу через вложенную структуру
        osmo_timer_schedule(timer, cfg->test_sai.interval_sec, 0);
    }
}


int main(int argc, char **argv)
{
    // Initialize STP and Load Config
    if (init_proxy(argc, argv) != 0) {
        fprintf(stderr, "Failed to initialize proxy core components\n");
        return 1;
    }

    // GSUP Server Setup
    // Note: You can also make the GSUP port configurable via VTY if needed
    uint16_t gsup_port = 4222;
    char gsup_ip[] = "0.0.0.0";

    // If you want to bind to a specific IP from config, you'd need to add that to proxy_cfg
    gsup_to_map_proxy->gsup_bind_addr = &gsup_ip[0];



    // Initialize C++ Proxy Core
    g_proxy_core = std::make_unique<grproxy::ProxyCore>(
        send_gsup_via_osmo,
        send_tcap_via_sccp
        );

    if (!g_proxy_core) {
        fprintf(stderr, "Failed to initialize proxy core\n");
        return 1;
    }

    g_proxy_core->test_parse_msgs();

    gsup_to_map_proxy->gs = osmo_gsup_server_create(tall_stp_ctx, gsup_to_map_proxy->gsup_bind_addr, gsup_port,
                                                    my_gsup_read_cb, my_gsup_connect_cb, gsup_to_map_proxy);
    if (!gsup_to_map_proxy->gs) {
        fprintf(stderr, "Failed to create GSUP server\n");
        return 1;
    }
    printf("GSUP server created successfully on %s:%u\n", gsup_to_map_proxy->gsup_bind_addr, gsup_port);

    // Setup Timers
    static struct osmo_timer_list send_timer;
    send_timer.cb = send_timer_cb;
    send_timer.data = &send_timer;

    const struct gsup_proxy_cfg *full_cfg = get_full_proxy_cfg();
    if (full_cfg && full_cfg->test_sai.enabled) {
        osmo_timer_schedule(&send_timer, full_cfg->test_sai.interval_sec, 0);
    }

   // struct osmo_gsup_message gsup_msg;
   // char imsi[] = "001010000007763";
   //  uint8_t sai_res3[] = { /*0x30 ,0x5b ,0x02 ,0x01 ,0x38 ,*/0xa3 ,0x56 ,0xa1 ,0x54 ,0x30 ,0x52 ,0x04 ,0x10 ,0x36 ,0x0f ,0x14
   //     ,0x22 ,0x0d ,0xc5 ,0x70 ,0xb0 ,0x18 ,0x75 ,0xf3 ,0x71 ,0x6f ,0x5c ,0x05 ,0x36 ,0x04 ,0x08 ,0xc6
   //      ,0x95 ,0xdf ,0x9f ,0xe6 ,0x32 ,0xd9 ,0xaf ,0x04,0x10 ,0xd9 ,0x5c ,0x5c ,0xe2 ,0x00 ,0x9d ,0x30
   //      ,0xd7 ,0x83 ,0xfa ,0xd3 ,0x02 ,0xd5 ,0x29 ,0x4a ,0xf7 ,0x04 ,0x10 ,0xb6 ,0x47 ,0xe3 ,0x3c ,0x11
   //      ,0x85 ,0x0d ,0x64 ,0x0b ,0xee ,0x5a ,0xbe ,0x2f ,0x5d ,0x90 ,0x76 ,0x04 ,0x10 ,0x01 ,0x6f ,0x1a
   //                        ,0xf8 ,0x21 ,0x11 ,0x00 ,0x00 ,0xfb ,0x98 ,0x0a ,0xd3 ,0x64 ,0x49 ,0x6d ,0x27};
   //  map_sai_res_to_gsup(sai_res3, sizeof(sai_res3),&gsup_msg, &imsi[0], OSMO_GSUP_CN_DOMAIN_PS);
    static struct osmo_timer_list cleanup_timer;
    cleanup_timer.cb = cleanup_timer_cb;
    cleanup_timer.data = &cleanup_timer;
    osmo_timer_schedule(&cleanup_timer, 30, 0);

    int rc;
    while (1) {
        rc = osmo_select_main_ctx(0);
        if (rc < 0)
            exit(3);
    }

    printf("Shutting down...\n");
    g_proxy_core.reset();
    talloc_free(tall_stp_ctx);
    return 0;
}



static int my_gsup_read_cb_send_err(struct osmo_gsup_conn *conn, struct msgb *msg)
{
    // ВАЖНО: osmo_gsup_conn_rx возвращает указатель, НЕ код ошибки!
    struct osmo_gsup_req *req = osmo_gsup_conn_rx(conn, msg);
    if (!req) {
        // osmo_gsup_conn_rx уже освободил msg в случае ошибки
        return -EINVAL;
    }

    LOGP(DLGSUP, LOGL_DEBUG, "RX %s for IMSI: %s\n",
         osmo_gsup_message_type_name(req->gsup.message_type),
         req->gsup.imsi);

    switch (req->gsup.message_type) {
    case OSMO_GSUP_MSGT_SEND_AUTH_INFO_REQUEST:
        LOGP(DLGSUP, LOGL_INFO, "Processing SEND_AUTH_INFO_REQUEST for IMSI: %s\n", req->gsup.imsi);

        // Отправляем ошибку аутентификации через правильную функцию
        osmo_gsup_req_respond_msgt(req,
                                   OSMO_GSUP_MSGT_SEND_AUTH_INFO_ERROR,

                                   true);  // final_response = true (завIMSI-001010000007763ершает транзакцию)
        //  req автоматически освобождается внутри osmo_gsup_req_respond_msgt()
        break;

    case OSMO_GSUP_MSGT_INSERT_DATA_REQUEST:
        LOGP(DLGSUP, LOGL_INFO, "Processing INSERT_DATA_REQUEST for IMSI: %s\n", req->gsup.imsi);

        // Отправляем успешный результат
        osmo_gsup_req_respond_msgt(req,
                                   OSMO_GSUP_MSGT_INSERT_DATA_RESULT,

                                   true);  // final_response = true
        //  req автоматически освобождается внутри
        break;

    case OSMO_GSUP_MSGT_UPDATE_LOCATION_REQUEST:
        LOGP(DLGSUP, LOGL_INFO, "Processing UPDATE_LOCATION_REQUEST for IMSI: %s\n", req->gsup.imsi);

        // Отправляем ошибку (абонент не найден в прокси)
        osmo_gsup_req_respond_msgt(req,
                                   OSMO_GSUP_MSGT_UPDATE_LOCATION_ERROR,

                                   true);  // final_response = true
        //  req автоматически освобождается внутри
        break;

    default:
        LOGP(DLGSUP, LOGL_NOTICE, "Unsupported GSUP message type: %s (0x%02x)\n",
             osmo_gsup_message_type_name(req->gsup.message_type),
             req->gsup.message_type);

        // Отправляем ошибку маршрутизации
        osmo_gsup_req_respond_msgt(req,
                                   OSMO_GSUP_MSGT_ROUTING_ERROR,

                                   true);  // final_response = true
        break;
    }


    // - НЕ вызываем msgb_free(msg) — он уже освобождён в osmo_gsup_conn_rx()
    // - НЕ вызываем osmo_gsup_req_free(req) — он освобождается в osmo_gsup_req_respond_msgt()
    return 0;
}







