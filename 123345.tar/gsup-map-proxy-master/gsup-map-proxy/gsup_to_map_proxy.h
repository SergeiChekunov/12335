#ifndef GSUP_TO_MAP_PROXY_H
#define GSUP_TO_MAP_PROXY_H

#ifdef __cplusplus
extern "C" {
#endif

#include <osmocom/core/linuxlist.h>
#include <osmocom/sigtran/osmo_ss7.h>
#include <osmocom/sigtran/sccp_helpers.h>
#include "hlr_1.h"

/* Объявление глобального talloc-контекста */
extern void *tall_stp_ctx;


/* Объявление глобальной переменной прокси */
extern struct hlr *gsup_to_map_proxy;

extern void process_msg_from_hlr(uint8_t *tcap_data , unsigned int tcap_len );

#ifdef __cplusplus
}
#endif

#endif /* GSUP_TO_MAP_PROXY_H */
