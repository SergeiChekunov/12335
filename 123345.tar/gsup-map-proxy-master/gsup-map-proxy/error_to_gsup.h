#ifndef ERROR_TO_GSUP_H
#define ERROR_TO_GSUP_H


#ifdef __cplusplus
extern "C" {
#endif


#include <osmocom/gsm/gsup.h>
#include <osmocom/core/logging.h>

/**
 * Преобразует MAP-ошибку в GSUP ERROR-сообщение.
 *
 * @param out_gsup_msg   Указатель на предварительно выделенную структуру GSUP-сообщения
 * @param gsup_type      Тип  GSUP-запроса
 * @param imsi           Строка IMSI (цифры, без пробелов)
 * @param error_code     Код ошибки MAP (0..255)
 * @return 0 при успехе, -1 при ошибке
 */
int error_to_gsup(struct osmo_gsup_message *out_gsup_msg,
                      enum osmo_gsup_message_type gsup_type,
                      const char *imsi, uint32_t error_code, bool is_abort);


#ifdef __cplusplus
}
#endif

#endif /* ERROR_TO_GSUP_H */
