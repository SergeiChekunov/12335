#ifndef ISDN_ADR_UTILITY_H
#define ISDN_ADR_UTILITY_H

#include "ISDN-AddressString.h"

/**
 * Декодирование ISDN-AddressString (MSISDN) в строку (для отладки)
 * и подготовка к копированию сырых данных.
 */
static char *decode_isdn_address_dbg(const ISDN_AddressString_t *isdn) {
    if (!isdn || !isdn->buf || isdn->size < 2) return NULL;
    const uint8_t *buf = isdn->buf;
    size_t len = isdn->size;
    char *str = (char*)calloc(1, len * 2 + 1);
    if (!str) return NULL;
    size_t pos = 0;
    // Пропускаем байт заголовка (buf[0])
    for (size_t i = 1; i < len; i++) {
        uint8_t low = buf[i] & 0x0F;
        uint8_t high = (buf[i] >> 4) & 0x0F;
        if (low <= 9) str[pos++] = low + '0';
        if (high <= 9 && pos < len * 2) str[pos++] = high + '0';
        if (high == 0xF) break;
    }
    str[pos] = '\0';
    return str;
}

#endif // ISDN_ADR_UTILITY_H
