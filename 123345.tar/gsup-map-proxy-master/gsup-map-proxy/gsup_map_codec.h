#ifndef GSUP_MAP_CODEC_H
#define GSUP_MAP_CODEC_H

#include <stdint.h>
#include <stddef.h>
#include <osmocom/gsm/gsup.h>
#include <osmocom/core/msgb.h>

/* MAP Operation Codes (из 3GPP TS 29.002) */
#define MAP_OP_CODE_SEND_AUTH_INFO 57  /* sendAuthenticationInfo */

/**
 * Преобразует GSUP-запрос аутентификации в MAP-сообщение SendAuthenticationInfoArg
 *
 * @param gsup       GSUP-сообщение с запросом аутентификации
 * @param map_msg    Буфер msgb для формирования MAP-сообщения
 * @param invoke_id  Идентификатор вызова MAP (invoke ID)
 * @returns          0 при успехе, отрицательное значение при ошибке (-EINVAL и др.)
 */
int gsup2map_send_auth_info(const struct osmo_gsup_message *gsup,
                            struct msgb *map_msg,
                            uint32_t invoke_id);

/**
 * Преобразует ответ MAP SendAuthenticationInfo в GSUP-сообщение
 *
 * @note Реализация требует полноценного ASN.1 декодера. Текущая версия возвращает заглушку с ошибкой.
 *
 * @param map_data   Указатель на закодированные данные MAP
 * @param map_len    Длина данных MAP
 * @param gsup       GSUP-сообщение для заполнения результатом
 * @returns          0 при успехе, отрицательное значение при ошибке (-ENOTSUP для неподдерживаемых операций)
 */
int map2gsup_send_auth_info(const uint8_t *map_data, size_t map_len,
                            struct osmo_gsup_message *gsup);

#endif /* GSUP_MAP_CODEC_H */
