#include "gsup_map_codec.h"
#include <osmocom/gsm/gsup.h>
#include <osmocom/gsm/gsm48.h>
#include <osmocom/core/utils.h>
#include <osmocom/core/logging.h>
#include <osmocom/sccp/sccp.h>
#include <osmocom/sigtran/protocol/sua.h>
#include <string.h>

/* MAP Operation Codes (из 3GPP TS 29.002) */
#define MAP_OP_CODE_SEND_AUTH_INFO 57  /* sendAuthenticationInfo */

/* Простая структура транзакции для сопоставления запросов/ответов */
struct gsup_map_trans {
    struct llist_head list;
    uint32_t trans_id;
    struct osmo_gsup_conn *gsup_conn;
    char imsi[16];
    enum osmo_gsup_message_type gsup_msg_type;
    uint32_t map_invoke_id;
};

/* Вспомогательная функция для добавления произвольных данных в msgb */
static inline void msgb_put_buffer(struct msgb *msg, const uint8_t *data, size_t len)
{
    uint8_t *ptr = msgb_put(msg, len);
    memcpy(ptr, data, len);
}

/* Преобразование GSUP SEND_AUTH_INFO_REQUEST → MAP SendAuthenticationInfoArg */
int gsup2map_send_auth_info(const struct osmo_gsup_message *gsup,
                            struct msgb *map_msg,
                            uint32_t invoke_id)
{
    uint8_t imsi_bcd[10];
    int imsi_len = gsm48_encode_bcd_number(imsi_bcd, sizeof(imsi_bcd), 0, gsup->imsi);
    if (imsi_len <= 0)
        return -EINVAL;

    /* Запоминаем позицию для исправления длины компонента позже */
    uint8_t *comp_len_ptr;
    uint8_t *seq_len_ptr;

    /* Component Type: Invoke (0x6C) */
    msgb_put_u8(map_msg, 0x6C);
    comp_len_ptr = msgb_put(map_msg, 1); /* placeholder для длины компонента */

    /* Invoke ID */
    msgb_put_u8(map_msg, 0x02);  /* Tag: invoke-id */
    msgb_put_u8(map_msg, 0x01);  /* Length */
    msgb_put_u8(map_msg, invoke_id & 0xFF);

    /* Operation Code */
    msgb_put_u8(map_msg, 0x02);  /* Tag: operation-code */
    msgb_put_u8(map_msg, 0x01);  /* Length */
    msgb_put_u8(map_msg, MAP_OP_CODE_SEND_AUTH_INFO);

    /* Parameter Sequence (SEQUENCE) */
    msgb_put_u8(map_msg, 0x30);  /* SEQUENCE tag */
    seq_len_ptr = msgb_put(map_msg, 1); /* placeholder для длины SEQUENCE */

    /* IMSI parameter (context-specific tag [0]) */
    msgb_put_u8(map_msg, 0x80);  /* Parameter tag: imsi [0] */
    msgb_put_u8(map_msg, imsi_len);
    msgb_put_buffer(map_msg, imsi_bcd, imsi_len);

    /* Исправляем длину SEQUENCE (содержимое после тега 0x30) */
    size_t seq_content_len = 2 + imsi_len; /* tag(1) + len(1) + data(imsi_len) */
    *seq_len_ptr = (uint8_t)seq_content_len;

    /* Исправляем длину всего компонента (после тега 0x6C) */
    size_t comp_content_len = (map_msg->tail - comp_len_ptr) - 1; /* минус байт длины */
    *comp_len_ptr = (uint8_t)comp_content_len;

    LOGP(DLGSUP, LOGL_DEBUG, "Encoded MAP SendAuthenticationInfo for IMSI %s (invoke-id=%u)\n",
         gsup->imsi, invoke_id);
    return 0;
}

/* Обратное преобразование: MAP ответ → GSUP */
int map2gsup_send_auth_info(const uint8_t *map_data, size_t map_len,
                            struct osmo_gsup_message *gsup)
{
    /* В реальной реализации здесь должен быть полный ASN.1 декодер.
     * Для демонстрации возвращаем заглушку с ошибкой */

    gsup->message_type = OSMO_GSUP_MSGT_SEND_AUTH_INFO_ERROR;
    gsup->cause = GMM_CAUSE_NET_FAIL;
    LOGP(DLGSUP, LOGL_ERROR, "MAP→GSUP conversion not fully implemented yet!\n");
    return -ENOTSUP;
}
