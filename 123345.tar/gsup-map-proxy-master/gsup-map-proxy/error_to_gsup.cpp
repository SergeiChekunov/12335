#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <string.h>





#include "error_to_gsup.h"



#ifndef DGPRS
#define DGPRS DLGLOBAL
#endif

#define LOG_GSUP(level, fmt, args...) \
LOGP(DGPRS, level, "MAP-ERROR→GSUP: " fmt, ##args)

/**
 * Преобразует MAP-ошибку в GSUP ERROR-сообщение.
 *
 * @param out_gsup_msg   Указатель на предварительно выделенную структуру GSUP-сообщения
 * @param initial_type   Тип исходного GSUP-запроса (например, _REQUEST)
 * @param imsi           Строка IMSI (цифры, без пробелов)
 * @param error_code     Код ошибки MAP (0..255)
 * @return 0 при успехе, -1 при ошибке
 */
int error_to_gsup(struct osmo_gsup_message *out_gsup_msg,
                      enum osmo_gsup_message_type gsup_type,
                      const char *imsi, uint32_t error_code, bool is_abort)
{
    if (!out_gsup_msg || !imsi)
        return -1;

    //if( ! OSMO_GSUP_IS_MSGT_ERROR(out_gsup_msg->message_type) )
    //   return -1;

    memset(out_gsup_msg, 0, sizeof(*out_gsup_msg));
    out_gsup_msg->message_type = gsup_type;

    if (imsi && imsi[0]) {
        strncpy(out_gsup_msg->imsi, imsi, sizeof(out_gsup_msg->imsi) - 1);
        out_gsup_msg->imsi[sizeof(out_gsup_msg->imsi) - 1] = '\0';
        LOG_GSUP(LOGL_DEBUG, "IMSI: %s\n", out_gsup_msg->imsi);
    }

    if(!is_abort)
        out_gsup_msg->cause = GMM_CAUSE_IMSI_UNKNOWN; //TODO: Convert Error Code
    else out_gsup_msg->message_type = OSMO_GSUP_MSGT_ROUTING_ERROR;

    return 0;
}
